<?php

$con=mysqli_connect('db403-mysql', 'root', 'P@ssw0rd', 'northwind') or die ("เกิดข้อผิดพลาด");

echo "เชื่อมต่อสำเร็จ" 
?>